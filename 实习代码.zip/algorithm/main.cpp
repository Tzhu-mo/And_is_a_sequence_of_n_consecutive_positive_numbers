#include <iostream>
#include <chrono>

using namespace std;

void f(int n);

int main()
{

    int n;
    cout << "������һ������"<<endl;
    cin >> n;
    auto start = std::chrono::high_resolution_clock::now();
    f(n);

    auto finish = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = finish - start;
    std::cout << "��������ʱ�䣺 " << elapsed.count() << " ��" << std::endl;

    return 0;
}
void f(int n){
    int small = 1;
    int big = 2;
    int sum = 3;
    int lastNum = (n+1)/2;

    while(small < lastNum){
        if(sum > n){
            sum -= small;
            small++;
        }else if(sum == n){
            for(int i = small;i <= big;i++){
                cout<<i<<" ";
            }
            cout<<endl;
            sum -= small;
            small++;
        }else if(sum < n){
            big++;
            sum += big;
        }
    }
}

#include <iostream>
#include <math.h>
#include <chrono>

using namespace std;

void f(int n);
void Put(int Start,int End);
int main()
{

    int n;
    cout << "������һ������"<<endl;
    cin >> n;
    auto start = std::chrono::high_resolution_clock::now();
    f(n);

    auto finish = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = finish - start;
    std::cout << "��������ʱ�䣺 " << elapsed.count() << " ��" << std::endl;

    return 0;
}
void f(int n){
    int Start = 0;
    int End = 0;
    int i = 2;
    int t = 0;
    while(i < sqrt(2*n)){
        if((2*n)%i == 0){
            t = (2*n - i*i + i)/i;
            Start = t/2;
            End = i + Start - 1;
            if(Start > 0&&Start%1 == 0&&(t%2 == 0))
                Put(Start,End);
        }
        i++;
    }
}
void Put(int Start,int End){
    for(int i = Start;i <= End;i++){
        cout<<i<<" ";
    }
    cout<<endl;
}
